function solve(){
  //TODO
  
}