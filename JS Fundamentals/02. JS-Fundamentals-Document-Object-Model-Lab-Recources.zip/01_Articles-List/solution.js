function solve() {
	//TODO
}