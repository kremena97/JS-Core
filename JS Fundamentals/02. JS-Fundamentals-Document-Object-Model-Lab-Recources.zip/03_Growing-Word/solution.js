function solve() {
   //TODO 
}